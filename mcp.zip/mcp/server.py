from mcp.server import FastMCP


server = FastMCP(
    name="python-mcp-demo",
    host="0.0.0.0",
    port=8000,
)


@server.tool(
    name="generate_dummy_user",
    description="Returns a fake email and phone number.",
)
def generate_dummy_user() -> dict[str, str]:
    return {
        "email": "demo.user@example.com",
        "phone": "+1-202-555-0199"
    }


@server.tool(
    name="add_numbers",
    description="Add two numbers",
)
def add_numbers(a: float, b: float) -> dict[str, float]:
    return {
        "result": a + b
    }


if __name__ == "__main__":
    server.run(transport="streamable-http")
